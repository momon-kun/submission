const storage = new Map();
module.exports = storage;